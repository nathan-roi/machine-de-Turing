# TP 1 - Machine de Turing

# Lancer le simulateur

- Commence par lancer le `index.html` et le tour est joué.
- Puis charge un fichier `.mt` avec le superbe bouton **choisir un fichier.**
- Enfin, entre un mot à vérifier dans la zone prévue et clique sur **CHECK.**